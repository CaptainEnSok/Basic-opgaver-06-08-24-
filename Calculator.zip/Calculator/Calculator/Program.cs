﻿namespace Calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int calculation = 0;
            while (calculation == 0)
            {
                Console.WriteLine("Insert Math Equation here! Please put a space in between each number and symbol :D");
                string equationAsk = Console.ReadLine();
                string[] equationSplit = equationAsk.Split(" ");

                if (equationAsk == "0/0")
                {
                    Console.WriteLine("You can't Divide by zero!");
                }
                else if (equationSplit[1] == "+")
                {
                    int digit1 = Int32.Parse(equationSplit[0]);
                    int digit2 = int.Parse(equationSplit[2]);
                    int result = digit1 + digit2;
                    Console.WriteLine($"{result}");
                }
                else if (equationSplit[1] == "-")
                {
                    int digit1 = Int32.Parse(equationSplit[0]);
                    int digit2 = int.Parse(equationSplit[2]);
                    int result = digit1 - digit2;
                    Console.WriteLine($"{result}");
                }
                else if (equationSplit[1] == "*")
                {
                    int digit1 = Int32.Parse(equationSplit[0]);
                    int digit2 = int.Parse(equationSplit[2]);
                    int result = digit1 * digit2;
                    Console.WriteLine($"{result}");
                }
                else if (equationSplit[1] == "/")
                {
                    int digit1 = Int32.Parse(equationSplit[0]);
                    int digit2 = int.Parse(equationSplit[2]);
                    int result = digit1 / digit2;
                    Console.WriteLine($"{result}");
                }
                else
                {
                    Console.WriteLine("An error occured!");
                }
            }

        }
    }
}
